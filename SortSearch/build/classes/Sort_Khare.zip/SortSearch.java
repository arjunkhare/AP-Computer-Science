
import java.util.Random;
import java.util.Arrays;

public class SortSearch {
    
    int[] intArray;
    int lenArray;
    
    public SortSearch(int lenArray){
     
        intArray = new int[lenArray];
        
        Random rand = new Random();
        for(int i = 0; i < lenArray; i++){
         
            this.intArray[i] = rand.nextInt(10);
            
        }
        
    }
    
    public void bubbleSort(int[] intArray, int way){
        
        int moveInt;
        
        System.out.println("Bubble Sort:");
        System.out.println(Arrays.toString(intArray));
        
        if(way == 0){
            
            for(int j = 0; j < intArray.length - 1; j++){
            
                for(int i = 1; i < intArray.length - j; i++){

                    if (intArray[i] < intArray[i-1]){

                        moveInt = intArray[i];
                        intArray[i] = intArray[i-1];
                        intArray[i-1] = moveInt;
                        
                        System.out.println(Arrays.toString(intArray));

                    }
                
                }
            
            }
            
        } else {
            
            for(int j = 0; j < intArray.length-1; j++){
            
                for(int i = 1; i < intArray.length- j; i++){

                    if (intArray[i] > intArray[i-1]){

                        moveInt = intArray[i];
                        intArray[i] = intArray[i-1];
                        intArray[i-1] = moveInt;

                    }
                
                }
                
                System.out.println(Arrays.toString(intArray));
            
            }
            
        }
        
    }
    
    public void selectionSort(int[] intArray, int way){
        
        int moveInt;
        
        System.out.println("Selection Sort:");
        System.out.println(Arrays.toString(intArray));
        
        if(way == 0){
            
            for (int i = 0; i < intArray.length - 1; i++){
            
                int index = i;
            
                for (int j = i + 1; j < intArray.length; j++){
                
                    if (intArray[j] < intArray[index]){
                    
                        index = j;
                    
                    }
                
                }      
      
            moveInt = intArray[index]; 
            intArray[index] = intArray[i];
            intArray[i] = moveInt;
            System.out.println(Arrays.toString(intArray));

            }
            
        } else {
            
            for (int i = 0; i < intArray.length - 1; i++){
            
                int index = i;
            
                for (int j = i + 1; j < intArray.length; j++){
                
                    if (intArray[j] > intArray[index]){
                    
                        index = j;
                    
                    }
                
                }      
      
            moveInt = intArray[index]; 
            intArray[index] = intArray[i];
            intArray[i] = moveInt;
            System.out.println(Arrays.toString(intArray));
            
            }
        
        }
        
    }
    
    public void insertionSort(int[] intArray, int way){
        
        int moveInt;
        
        System.out.println("Insertion Sort:");
        System.out.println(Arrays.toString(intArray));
        
        if(way == 0){
            
            for (int i = 1; i < intArray.length; i++) {
            
                moveInt = intArray[i];
                int index = i;

                while (index > 0 && intArray[index-1] > moveInt) {
                    
                    intArray[index] = intArray[index-1];
                    index--;
                
                }

                intArray[index] = moveInt;
                System.out.println(Arrays.toString(intArray));
                
            }
            
        } else {
            
            for (int i = 1; i < intArray.length; i++) {
            
                moveInt = intArray[i];
                int index = i;

                while (index > 0 && intArray[index-1] < moveInt) {
                    
                    intArray[index] = intArray[index-1];
                    index--;
                
                }

                intArray[index] = moveInt;
                System.out.println(Arrays.toString(intArray));
                
            }
            
        }
          
    }
    
    public void unknown(int w[],int i){           
       
        if (i >= w.length-1){
            
            System.out.print(w[i]+", ");
            
        }
            
        else{
            
            unknown(w,i+1);
            System.out.print(w[i]+", ");
        
        }
        
    }
    
    public static void main(String[] args){
        
        int[] Array1 = {1, 8, 4, 6, 3, 9, 8, 4, 0, 2};
        SortSearch bubbleSorted = new SortSearch(10);
        bubbleSorted.bubbleSort(Array1, 0);                  //Second parameter is 0 for ascending and any other int for descending.
        
        System.out.println();
        
        int[] Array2 = {1, 8, 4, 6, 3, 9, 8, 4, 0, 2};
        SortSearch selectionSorted = new SortSearch(10);
        selectionSorted.selectionSort(Array2, 0);
        
        System.out.println();
        
        int[] Array3 = {1, 8, 4, 6, 3, 9, 8, 4, 0, 2};
        SortSearch insertionSorted = new SortSearch(10);
        insertionSorted.insertionSort(Array3, 0);
        
        System.out.println();
        
        insertionSorted.unknown(Array3, 0);
        
        System.out.println();
        
    }
    
}
